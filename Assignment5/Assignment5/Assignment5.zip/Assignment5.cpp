#include <iostream>
#include "Queue.h"

using namespace std;

int main() {
    Queue * q = new Queue(10);
    q->menu();
    return 0;
}
